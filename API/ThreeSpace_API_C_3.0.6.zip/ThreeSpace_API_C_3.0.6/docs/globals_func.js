var globals_func =
[
    [ "_", "globals_func.html", null ],
    [ "t", "globals_func_t.html", null ]
];