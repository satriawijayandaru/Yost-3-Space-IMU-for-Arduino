var struct_tss_com_port =
[
    [ "connection_type", "struct_tss_com_port.html#aa6095497f1cb4fbb1125dfdb7b6317ce", null ],
    [ "device_type", "struct_tss_com_port.html#a78e55ad07230df86ca4d75605be23e39", null ],
    [ "port_name", "struct_tss_com_port.html#ac676aced56eb38335d022a86a8aa77c2", null ]
];