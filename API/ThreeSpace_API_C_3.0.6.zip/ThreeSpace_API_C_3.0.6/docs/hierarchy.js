var hierarchy =
[
    [ "TSS_ComPort", "struct_t_s_s___com_port.html", null ],
    [ "TSS_Header", "struct_t_s_s___header.html", null ],
    [ "TSS_Stream_Packet", "struct_t_s_s___stream___packet.html", null ],
    [ "TssAPI", "class_tss_a_p_i.html", null ],
    [ "TssComPort", "struct_tss_com_port.html", null ],
    [ "TssDevice", "class_tss_device.html", [
      [ "TssDongle", "class_tss_dongle.html", null ],
      [ "TssSensor", "class_tss_sensor.html", null ]
    ] ],
    [ "TssStreamPacketCircularBuffer", "struct_tss_stream_packet_circular_buffer.html", null ]
];