var group__tss__api__methods =
[
    [ "tss_deinitAPI", "group__tss__api__methods.html#gadd173ebc36d435842c6f191882b58921", null ],
    [ "tss_initAPI", "group__tss__api__methods.html#ga0529cd22849973f5013ab13a11c10a5b", null ]
];