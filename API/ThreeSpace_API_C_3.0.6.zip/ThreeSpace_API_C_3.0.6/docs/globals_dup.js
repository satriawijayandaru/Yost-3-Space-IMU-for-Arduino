var globals_dup =
[
    [ "_", "globals.html", null ],
    [ "b", "globals_b.html", null ],
    [ "f", "globals_f.html", null ],
    [ "g", "globals_g.html", null ],
    [ "i", "globals_i.html", null ],
    [ "n", "globals_n.html", null ],
    [ "r", "globals_r.html", null ],
    [ "t", "globals_t.html", null ],
    [ "u", "globals_u.html", null ]
];