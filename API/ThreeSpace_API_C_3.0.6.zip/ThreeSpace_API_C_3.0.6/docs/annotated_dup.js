var annotated_dup =
[
    [ "TSS_ComPort", "struct_t_s_s___com_port.html", "struct_t_s_s___com_port" ],
    [ "TSS_Header", "struct_t_s_s___header.html", "struct_t_s_s___header" ],
    [ "TSS_Stream_Packet", "struct_t_s_s___stream___packet.html", "struct_t_s_s___stream___packet" ],
    [ "TssAPI", "class_tss_a_p_i.html", "class_tss_a_p_i" ],
    [ "TssComPort", "struct_tss_com_port.html", "struct_tss_com_port" ],
    [ "TssDevice", "class_tss_device.html", "class_tss_device" ],
    [ "TssDongle", "class_tss_dongle.html", "class_tss_dongle" ],
    [ "TssSensor", "class_tss_sensor.html", "class_tss_sensor" ],
    [ "TssStreamPacketCircularBuffer", "struct_tss_stream_packet_circular_buffer.html", "struct_tss_stream_packet_circular_buffer" ]
];