var searchData=
[
  ['datalength',['DataLength',['../struct_t_s_s___header.html#a6612c7e279c5dd0adce1b7570c0fdb2b',1,'TSS_Header']]],
  ['device_5ftype',['device_type',['../struct_tss_com_port.html#a78e55ad07230df86ca4d75605be23e39',1,'TssComPort::device_type()'],['../struct_t_s_s___com_port.html#ac90e3ebb46456dc5d0a3f6ab6de97cf7',1,'TSS_ComPort::device_type()']]]
];
