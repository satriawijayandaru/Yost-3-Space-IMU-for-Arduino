var searchData=
[
  ['unregisterstreamingdevice',['unregisterStreamingDevice',['../class_tss_a_p_i.html#a59830c3af155f86e031386eaa7e0d680',1,'TssAPI']]],
  ['updatecurrenttimestamp',['updateCurrentTimestamp',['../class_tss_sensor.html#a1266eedc6ca175d29ef29ed348e5ba86',1,'TssSensor']]]
];
