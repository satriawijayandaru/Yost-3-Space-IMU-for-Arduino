var searchData=
[
  ['formatandinitializesdcard',['formatAndInitializeSDCard',['../class_tss_sensor.html#a7aa1bfcfed12b598a7dd30e831da4c55',1,'TssSensor']]]
];
