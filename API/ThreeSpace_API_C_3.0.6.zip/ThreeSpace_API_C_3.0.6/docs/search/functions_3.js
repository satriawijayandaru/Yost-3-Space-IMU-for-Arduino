var searchData=
[
  ['clear',['clear',['../struct_tss_stream_packet_circular_buffer.html#ac8bb3912a3ce86b15842e79d0b421204',1,'TssStreamPacketCircularBuffer']]],
  ['closeport',['closePort',['../class_tss_dongle.html#a89b82d195141bb799ea0d3c2d9285f6f',1,'TssDongle::closePort()'],['../class_tss_sensor.html#a89b82d195141bb799ea0d3c2d9285f6f',1,'TssSensor::closePort()']]],
  ['commitsettings',['commitSettings',['../class_tss_sensor.html#aab8a8278a4e96f526f5dfd5cf7f85074',1,'TssSensor']]],
  ['commitwirelesssettings',['commitWirelessSettings',['../class_tss_dongle.html#a1afc2cbc8ef7ba2a2ac706d17872923e',1,'TssDongle::commitWirelessSettings()'],['../class_tss_sensor.html#a1afc2cbc8ef7ba2a2ac706d17872923e',1,'TssSensor::commitWirelessSettings()']]]
];
