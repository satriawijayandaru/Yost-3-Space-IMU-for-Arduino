var searchData=
[
  ['port_5fname',['port_name',['../struct_tss_com_port.html#ac676aced56eb38335d022a86a8aa77c2',1,'TssComPort::port_name()'],['../struct_t_s_s___com_port.html#a08696845518a2c63a1198378c134486f',1,'TSS_ComPort::port_name()']]]
];
