var searchData=
[
  ['offsetwithcurrentorientation',['offsetWithCurrentOrientation',['../class_tss_sensor.html#acdf4cace8ff664bc46a7549ccac205f0',1,'TssSensor']]],
  ['offsetwithquaternion',['offsetWithQuaternion',['../class_tss_sensor.html#a4e3867ced893754de51451254ff3d0b4',1,'TssSensor']]],
  ['openport',['openPort',['../class_tss_dongle.html#a8d83a8b0f8518f8648cae28063f5fb2e',1,'TssDongle::openPort()'],['../class_tss_sensor.html#a8d83a8b0f8518f8648cae28063f5fb2e',1,'TssSensor::openPort()']]],
  ['operator_3d',['operator=',['../class_tss_dongle.html#a0d25d31e85688d9ae63d559f1b080b31',1,'TssDongle::operator=()'],['../class_tss_sensor.html#a81e030f24d994d2a0af3b70049f9d6bb',1,'TssSensor::operator=()']]]
];
