var searchData=
[
  ['init',['init',['../class_tss_a_p_i.html#a02fd73d861ef2e4aabb38c0c9ff82947',1,'TssAPI']]],
  ['isconnected',['isConnected',['../class_tss_device.html#a772f8f0487e0d3804e9da7585e23a29a',1,'TssDevice']]]
];
