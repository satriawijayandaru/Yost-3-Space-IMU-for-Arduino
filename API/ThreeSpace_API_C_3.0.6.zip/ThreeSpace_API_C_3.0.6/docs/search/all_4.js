var searchData=
[
  ['datalength',['DataLength',['../struct_t_s_s___header.html#a6612c7e279c5dd0adce1b7570c0fdb2b',1,'TSS_Header']]],
  ['deinit',['deinit',['../class_tss_a_p_i.html#a967fb9235af58c66165b0d619c6cc584',1,'TssAPI']]],
  ['device_5ftype',['device_type',['../struct_tss_com_port.html#a78e55ad07230df86ca4d75605be23e39',1,'TssComPort::device_type()'],['../struct_t_s_s___com_port.html#ac90e3ebb46456dc5d0a3f6ab6de97cf7',1,'TSS_ComPort::device_type()']]],
  ['didstreamingoverflow',['didStreamingOverflow',['../class_tss_sensor.html#a72e231589146fd209097a85a823da9f7',1,'TssSensor']]],
  ['disablestreamingwireless',['disableStreamingWireless',['../class_tss_sensor.html#af89e3ecddb357835fff7b82347bde5ed',1,'TssSensor']]],
  ['disabletimestampswired',['disableTimestampsWired',['../class_tss_sensor.html#a0127d069e1d54249e712db254090a836',1,'TssSensor']]],
  ['disabletimestampswireless',['disableTimestampsWireless',['../class_tss_dongle.html#a086ae2da4e612efd2f06f9daee4d31f9',1,'TssDongle']]],
  ['dongle_20functions',['Dongle Functions',['../group__tss__dongle__methods.html',1,'']]]
];
