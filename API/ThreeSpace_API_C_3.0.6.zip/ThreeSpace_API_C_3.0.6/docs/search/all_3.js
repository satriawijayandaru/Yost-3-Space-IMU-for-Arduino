var searchData=
[
  ['checksum',['Checksum',['../struct_t_s_s___header.html#ae5ee97905e38b068d8fbff3abb3af073',1,'TSS_Header']]],
  ['clear',['clear',['../struct_tss_stream_packet_circular_buffer.html#ac8bb3912a3ce86b15842e79d0b421204',1,'TssStreamPacketCircularBuffer']]],
  ['closeport',['closePort',['../class_tss_dongle.html#a89b82d195141bb799ea0d3c2d9285f6f',1,'TssDongle::closePort()'],['../class_tss_sensor.html#a89b82d195141bb799ea0d3c2d9285f6f',1,'TssSensor::closePort()']]],
  ['commandecho',['CommandEcho',['../struct_t_s_s___header.html#aeb952c6a3d3ff53430418f9d248c78be',1,'TSS_Header']]],
  ['commitsettings',['commitSettings',['../class_tss_sensor.html#aab8a8278a4e96f526f5dfd5cf7f85074',1,'TssSensor']]],
  ['commitwirelesssettings',['commitWirelessSettings',['../class_tss_dongle.html#a1afc2cbc8ef7ba2a2ac706d17872923e',1,'TssDongle::commitWirelessSettings()'],['../class_tss_sensor.html#a1afc2cbc8ef7ba2a2ac706d17872923e',1,'TssSensor::commitWirelessSettings()']]],
  ['connection_5ftype',['connection_type',['../struct_tss_com_port.html#aa6095497f1cb4fbb1125dfdb7b6317ce',1,'TssComPort::connection_type()'],['../struct_t_s_s___com_port.html#ae5d716c44a132a0fc814c67c5bdb27fa',1,'TSS_ComPort::connection_type()']]],
  ['correctedaccelerometerdata',['correctedAccelerometerData',['../struct_t_s_s___stream___packet.html#ab5022e6d50f36cb339276fc2f07465f3',1,'TSS_Stream_Packet']]],
  ['correctedgyroscopedata',['correctedGyroscopeData',['../struct_t_s_s___stream___packet.html#ac24d05e8647e8798842e55111df6e491',1,'TSS_Stream_Packet']]],
  ['correctedmagnetometerdata',['correctedMagnetometerData',['../struct_t_s_s___stream___packet.html#a8df20636c83c159701e743b17260e39e',1,'TSS_Stream_Packet']]],
  ['correctedsensordata',['correctedSensorData',['../struct_t_s_s___stream___packet.html#a5437ee5f122452cc98e4161a6964a10e',1,'TSS_Stream_Packet']]]
];
