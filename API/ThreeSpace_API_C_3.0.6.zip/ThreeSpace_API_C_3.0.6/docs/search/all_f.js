var searchData=
[
  ['rawaccelerometerdata',['rawAccelerometerData',['../struct_t_s_s___stream___packet.html#aaa96058395104f186e6de618856464f6',1,'TSS_Stream_Packet']]],
  ['rawdata',['rawData',['../struct_t_s_s___stream___packet.html#a49c29726a360ea80c0266d8a2bd7e268',1,'TSS_Stream_Packet']]],
  ['rawdatasize',['rawDataSize',['../struct_t_s_s___stream___packet.html#a35dcad27d3929d49f8b5221add941cd6',1,'TSS_Stream_Packet']]],
  ['rawgyroscopedata',['rawGyroscopeData',['../struct_t_s_s___stream___packet.html#a01648e69c92bf9ed783c6a24abad9508',1,'TSS_Stream_Packet']]],
  ['rawmagnetometerdata',['rawMagnetometerData',['../struct_t_s_s___stream___packet.html#ad47cc892f307ad4bd18a12734fa45f3c',1,'TSS_Stream_Packet']]],
  ['rawsensordata',['rawSensorData',['../struct_t_s_s___stream___packet.html#a0dbd00b5b6e4a4ec4331dbcd23cf6cc5',1,'TSS_Stream_Packet']]],
  ['registerstreamingdevice',['registerStreamingDevice',['../class_tss_a_p_i.html#ac4f7b46bcca80ad7b062cd822e55377f',1,'TssAPI']]],
  ['removefirstpacket',['removeFirstPacket',['../struct_tss_stream_packet_circular_buffer.html#abae980c103c4b13a45ccdd4ffbb95191',1,'TssStreamPacketCircularBuffer']]],
  ['removewirelesssensor',['removeWirelessSensor',['../class_tss_dongle.html#aa0e24db43b36d4b181e183df1427fd2a',1,'TssDongle']]],
  ['resetbaseoffset',['resetBaseOffset',['../class_tss_sensor.html#ac02792b343886f4775498f45b4206ed8',1,'TssSensor']]],
  ['resetkalmanfilter',['resetKalmanFilter',['../class_tss_sensor.html#a9e9ac85b2e7b280ab687f505cee51d78',1,'TssSensor']]],
  ['resetsteps',['resetSteps',['../class_tss_sensor.html#a8f3abe5f40ea6bd9460ac073468e4210',1,'TssSensor']]],
  ['restorefactorysettings',['restoreFactorySettings',['../class_tss_sensor.html#a4b0015f1b4aaf1bf6cf8da927e5a2e8d',1,'TssSensor']]],
  ['result',['result',['../threespace__device_8hpp.html#a194f03d0b8f2f72c4ba164f379b16bff',1,'threespace_device.hpp']]]
];
