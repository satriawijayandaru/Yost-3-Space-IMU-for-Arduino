var struct_t_s_s___com_port =
[
    [ "connection_type", "struct_t_s_s___com_port.html#ae5d716c44a132a0fc814c67c5bdb27fa", null ],
    [ "device_type", "struct_t_s_s___com_port.html#ac90e3ebb46456dc5d0a3f6ab6de97cf7", null ],
    [ "port_name", "struct_t_s_s___com_port.html#a08696845518a2c63a1198378c134486f", null ]
];