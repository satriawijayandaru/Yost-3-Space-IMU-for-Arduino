var threespace__dongle_8hpp =
[
    [ "TssDongle", "class_tss_dongle.html", "class_tss_dongle" ],
    [ "TSS_DEFAULT_WIRELESS_COMMAND_RETRIES", "threespace__dongle_8hpp.html#a180363532a4547b68dd8bc3a50fbf8f5", null ],
    [ "TSS_DONGLE_NUM_CHILDREN", "threespace__dongle_8hpp.html#a3999e1c62e981797f0b2c09c39aac6f7", null ]
];