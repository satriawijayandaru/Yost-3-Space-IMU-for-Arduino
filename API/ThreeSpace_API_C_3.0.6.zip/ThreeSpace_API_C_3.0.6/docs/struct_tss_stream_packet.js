var struct_tss_stream_packet =
[
    [ "header", "struct_tss_stream_packet.html#a7ce28699bb5417aaef7cb9c186c1a330", null ],
    [ "rawData", "struct_tss_stream_packet.html#aa10dd631096c7df0a9a035ca224261b0", null ],
    [ "rawDataSize", "struct_tss_stream_packet.html#a35dcad27d3929d49f8b5221add941cd6", null ],
    [ "taredOrientAngle", "struct_tss_stream_packet.html#a906fca59a4f0f3f11fdadfab1038bc0d", null ],
    [ "taredOrientAxis", "struct_tss_stream_packet.html#a788dc83725e08828acce804fe1561df0", null ],
    [ "taredOrientDown", "struct_tss_stream_packet.html#aa5209305cb8a5c59ee5deca3cb239f35", null ],
    [ "taredOrientEuler", "struct_tss_stream_packet.html#ab2d9efdb19a330df30a50abc7ffc74e5", null ],
    [ "taredOrientForward", "struct_tss_stream_packet.html#a43d77d4d5ebb372ecf619360cbb18db9", null ],
    [ "taredOrientMatrix", "struct_tss_stream_packet.html#a9e319ecc4af0ecf823444e31713e4561", null ],
    [ "taredOrientQuat", "struct_tss_stream_packet.html#a606c3029052ea203a464683c83a0919a", null ],
    [ "untaredOrientAngle", "struct_tss_stream_packet.html#a19f84f2fe6d7adf52bf8dc0b57b4425f", null ],
    [ "untaredOrientAxis", "struct_tss_stream_packet.html#ab532c991e40417d14bc9dcd391d323da", null ],
    [ "untaredOrientEuler", "struct_tss_stream_packet.html#aeeea1342643c738aeef6c6c15153fc99", null ],
    [ "untaredOrientGravity", "struct_tss_stream_packet.html#a3ef3096e15ea5fe80a87775b4f519d91", null ],
    [ "untaredOrientMatrix", "struct_tss_stream_packet.html#a194b2c622eb91b4fd2bf888f6697da52", null ],
    [ "untaredOrientNorth", "struct_tss_stream_packet.html#a60bd639b57ec7ddb154873959cdb23a0", null ],
    [ "untaredOrientQuat", "struct_tss_stream_packet.html#a289a44c896ae766cb9adece8f0d714b9", null ]
];