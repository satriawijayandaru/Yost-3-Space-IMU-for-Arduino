var struct_tss_header =
[
    [ "Checksum", "struct_tss_header.html#ae5ee97905e38b068d8fbff3abb3af073", null ],
    [ "CommandEcho", "struct_tss_header.html#aeb952c6a3d3ff53430418f9d248c78be", null ],
    [ "DataLength", "struct_tss_header.html#a6612c7e279c5dd0adce1b7570c0fdb2b", null ],
    [ "LogicalId", "struct_tss_header.html#a5fde307cc5e03f2baf0a34a786448b1e", null ],
    [ "SensorTimestamp", "struct_tss_header.html#a23d100be9039eecffcfd243f956b2a9a", null ],
    [ "SerialNumber", "struct_tss_header.html#afb4e5c15488eb2dfb39be68ec01314ee", null ],
    [ "Success", "struct_tss_header.html#a506fb037fbb6bfe8f254c021a2c3cfac", null ],
    [ "SystemTimestamp", "struct_tss_header.html#a25d11681c262d48075204aa97b5c6102", null ]
];